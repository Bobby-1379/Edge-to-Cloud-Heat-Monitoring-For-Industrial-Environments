main.o: main.c
main.o: uart0.h
main.o: delay.h
main.o: types.h
main.o: lcd.h
main.o: esp01.h
main.o: rtc.h
main.o: C:\KeilARM\ARM\INC\Philips\LPC214X.H
