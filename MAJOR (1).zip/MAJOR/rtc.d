rtc.o: rtc.c
rtc.o: C:\KeilARM\ARM\INC\Philips\lpc214x.h
rtc.o: rtc_defines.h
rtc.o: types.h
rtc.o: delay.h
