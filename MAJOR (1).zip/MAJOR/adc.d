adc.o: ADC.C
adc.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
adc.o: adc_defines.h
adc.o: types.h
